# swagger:ignore

Marks a struct as explicitly ignore from the Swagger spec output

<!--more-->

##### Syntax:

```
swagger:ignore
```
